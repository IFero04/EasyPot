#!/usr/bin/python3
#
# simple remove banned ip
#
import sys
import subprocess
import re
from src.core import *

try:
    ipaddress = sys.argv[1]
    if is_valid_ipv4(ipaddress):
        path = check_banlist_path()
        with open(path, "r") as file:
            data = file.read()
        
        data = data.replace(ipaddress + "\n", "")
        
        with open(path, "w") as file:
            file.write(data)

        print("Listing all iptables looking for a match... if there is a massive amount of blocked IPs this could take a few minutes..")
        proc = subprocess.Popen(
            f"iptables -L ARTILLERY -n -v --line-numbers | grep {ipaddress}", 
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True
        )

        for line in proc.stdout:
            line = line.decode("utf-8")
            match = re.search(ipaddress, line)
            if match:
                # this is the rule number
                line = line.split()[0]
                print(line)
                # delete it
                subprocess.Popen(
                    f"iptables -D ARTILLERY {line}", 
                    stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True
                )

    # if not valid then flag
    else:
        print("[!] Not a valid IP Address. Exiting.")
        sys.exit()

except IndexError:
    print("Description: Simple removal of IP address from banned sites.")
    print("[!] Usage: remove_ban.py <ip_address_to_ban>")
