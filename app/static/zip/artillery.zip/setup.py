#!/usr/bin/python3
#
# quick script for installing artillery
#

import subprocess
import os
from src.core import *
from src.pyuac import *  


def installation():
    init_globals()

    if not os.path.isdir("/var/artillery_check_root"):
        os.makedirs("/var/artillery_check_root")
    if not os.path.isdir("/var/artillery/database"):
        os.makedirs("/var/artillery/database")
    if not os.path.isdir("/var/artillery/src/program_junk"):
        os.makedirs("/var/artillery/src/program_junk")

    #Adding artillery into startup through init scripts
    if os.path.isdir("/etc/init.d"):
        if not os.path.isfile("/etc/init.d/artillery"):
            with open("/tmp/artillery/src/startup_artillery", "r") as fileopen:
                config = fileopen.read()
            with open("/etc/init.d/artillery", "w") as filewrite:
                filewrite.write(config)
            #Triggering update-rc.d on artillery to automatic start
            subprocess.Popen("chmod +x /etc/init.d/artillery", shell=True).wait()
            subprocess.Popen("update-rc.d artillery defaults", shell=True).wait()

        #Remove old method if installed previously
        if os.path.isfile("/etc/init.d/rc.local"):
            with open("/etc/init.d/rc.local", "r") as fileopen:
                data = fileopen.read()
            data = data.replace("sudo python /var/artillery/artillery.py &", "")
            with open("/etc/init.d/rc.local", "w") as filewrite:
                filewrite.write(data)

    subprocess.Popen("cp -rf /tmp/artillery/* /var/artillery/", shell=True).wait()
    check_config()
    
if __name__ == '__main__':
    installation()