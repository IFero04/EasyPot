#!/usr/bin/python3
################################################################################
#
#  Artillery - An active honeypotting tool and threat intelligence feed
#
# Written by Dave Kennedy (ReL1K) @HackingDave
#
# A Binary Defense Project (https://www.binarydefense.com) @Binary_Defense
#
################################################################################

import time
import sys
import os
import subprocess
import traceback
from src.pyuac import *
import src.globals
from src.core import *

# Initialize global variables
init_globals()

# Backwards compatibility for threading
try:
    import thread
except ImportError:
    import _thread as thread

# Ensure installation has been run
if not os.path.isfile(src.globals.g_appfile):
    print("[*] Artillery is not installed, running setup.py..")
    import setup

# Check for POSIX systems and ensure root privileges
if is_posix():
    try:
        if os.path.isdir("/var/artillery_check_root"):
            os.rmdir('/var/artillery_check_root')
    except OSError as e:
        if e.errno in [errno.EACCES, errno.EPERM]:
            print("[*] You must be root to run this script!\r\n")
            sys.exit(1)
    else:
        check_config()
        if not os.path.isdir(src.globals.g_apppath + "/database/"):
            os.makedirs(src.globals.g_apppath + "/database/")
        if not os.path.isfile(src.globals.g_apppath + "/database/temp.database"):
            with open(src.globals.g_apppath + "/database/temp.database", "w") as file:
                file.write("")

write_console("Artillery has started \nIf on Windows Ctrl+C to exit. \nConsole logging enabled.\n")
write_console(f"Artillery is running from '{src.globals.g_apppath}'")

# Prep everything for Artillery first run
check_banlist_path()

try:
    # Update Artillery
    if is_config_enabled("AUTO_UPDATE"):
        thread.start_new_thread(update, ())

    # Import base monitoring of fs
    if is_config_enabled("MONITOR") and is_posix():
        from src.monitor import *

    # Port ranges to spawn
    tcpport = read_config("TCPPORTS")
    udpport = read_config("UDPPORTS")

    # Create iptables chain if on POSIX
    if is_posix():
        time.sleep(2)
        write_console("Creating iptables entries, hold on.")
        create_iptables_subset()
        write_console("iptables entries created.")
        if is_config_enabled("ANTI_DOS"):
            write_console("Activating anti DoS.")
            import src.anti_dos

    # Spawn honeypot
    write_console("Launching honeypot.")
    import src.honeypot

    # Spawn SSH monitor
    if is_config_enabled("SSH_BRUTE_MONITOR") and is_posix():
        write_console("Launching SSH Bruteforce monitor.")
        import src.ssh_monitor

    # Spawn FTP monitor
    if is_config_enabled("FTP_BRUTE_MONITOR") and is_posix():
        write_console("Launching FTP Bruteforce monitor.")
        import src.ftp_monitor

    # Start monitor engine
    if is_config_enabled("MONITOR") and is_posix():
        write_console("Launching monitor engines.")
        import src.monitor
    if is_config_enabled("SYSTEM_HARDENING") and is_posix():
        write_console("Check system hardening.")
        import src.harden

    # Start the email handler
    if is_config_enabled("EMAIL_ALERTS") and is_posix():
        write_console("Launching email handler.")
        import src.email_handler

    # Check if we are a threat server
    if is_config_enabled("THREAT_SERVER"):
        write_console("Launching threat server thread.")
        thread.start_new_thread(threat_server, ())

    # Recycle IP addresses if enabled
    if is_config_enabled("RECYCLE_IPS"):
        write_console("Launching thread to recycle IP addresses.")
        thread.start_new_thread(refresh_log, ())

    # Pull additional source feeds
    write_console("Launching thread to get source feeds, if needed.")
    thread.start_new_thread(pull_source_feeds, ())

    # Let the program continue to run
    write_console("All set.")
    write_log("Artillery is up and running")
    while True:
        try:
            time.sleep(100000)
        except KeyboardInterrupt:
            print("\n[!] Exiting Artillery... hack the gibson.\n")
            sys.exit()

except KeyboardInterrupt:
    sys.exit()

except Exception as e:
    emsg = traceback.format_exc()
    print(f"General exception: {e}\n{emsg}")
    write_log(f"Error launching Artillery\n{emsg}", 2)
    sys.exit()
