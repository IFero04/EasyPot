#!/usr/bin/python3
#
# quick script for uninstall artillery
#

import subprocess
import os
from src.core import *
from src.pyuac import *  


def uninstall():
    os.remove("/etc/init.d/artillery")
    subprocess.Popen("rm -rf /var/artillery", shell=True).wait()
    subprocess.Popen("rm -rf /etc/init.d/artillery", shell=True).wait()
    kill_artillery()
    print("Artillery has been uninstalled. Manually kill the process if it is still running.")

if __name__ == '__main__':
    uninstall()