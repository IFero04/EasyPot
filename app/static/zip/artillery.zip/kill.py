#!/usr/bin/python3
#
# quick script for killing artillery
#

from src.core import *
from src.pyuac import *  


if __name__ == '__main__':
    kill_artillery()
    print("Artillery has been killed. Manually kill the process if it is still running.")